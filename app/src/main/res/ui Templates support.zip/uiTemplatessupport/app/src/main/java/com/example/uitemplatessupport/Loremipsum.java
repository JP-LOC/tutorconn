package com.example.uitemplatessupport;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Loremipsum extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loremipsum);
    }
}